package com.mckinleyit.parallel;

import com.mckinleyit.parallel.config.ParallelGroupConfig;
import com.mckinleyit.parallel.config.ParallelStageBuilderConfig;

import java.util.*;

public class ParallelStageBuilder {

    private Map<StageKey, Object> all;
    private int defaultMaxGroupSize;
    private List<ParallelStages> stages;

    public ParallelStageBuilder(Map<StageKey, Object> all, ParallelStageBuilderConfig parallelStageBuilderConfig) {
        this.all = all;
        this.stages = new ArrayList<>();
        this.defaultMaxGroupSize = parallelStageBuilderConfig.getMaxSize();
        if (parallelStageBuilderConfig.getParallelGroupConfigs() != null) {
            ParallelGroupConfig[] cfgs = parallelStageBuilderConfig.getParallelGroupConfigs();
            for (ParallelGroupConfig cfg : cfgs) {
                stages.add(new ParallelStages(cfg));
            }
        }
    }

    boolean hasStages() {
        return !all.isEmpty();
    }

    public Map<StageKey, Object> nextStages() {
        for (ParallelStages stgGroup : stages) {

            Map<StageKey, Object> next = stageFor(stgGroup);
            if (next.size() > 0) {
                return next;
            }
        }
        return getRemainingStages();
    }

    private Map<StageKey, Object> getRemainingStages() {

        if (this.defaultMaxGroupSize == 0) {
            throw new RuntimeException("No stage size set.");
        }

        Map<StageKey, Object> next = new HashMap<>();
        Iterator<StageKey> keys = all.keySet().iterator();
        while (keys.hasNext() && next.size() < this.defaultMaxGroupSize) {
            StageKey key = keys.next();
            next.put(key, all.get(key));
        }
        for (StageKey nextKey : next.keySet()) {
            all.remove(nextKey);
        }
        return next;
    }

    private Map<StageKey, Object> stageFor(ParallelStages grp) {

        int max = grp.getConfig().getMaxSize() > 0 ? grp.getConfig().getMaxSize() : this.defaultMaxGroupSize;
        if (max == 0) {
            throw new RuntimeException("No stage size set.");
        }

        Map<StageKey, Object> next = new HashMap<>();

        if (grp.getConfig().getExecutionLimit() > 0 && grp.getUsageCount() == grp.getConfig().getExecutionLimit()) {
            return next;
        }

        Iterator<StageKey> keys = all.keySet().iterator();
        while (keys.hasNext() && next.size() < max) {
            StageKey key = keys.next();

            boolean passes = true;
            for (GroupRule groupRule : grp.getConfig().getRules()) {
                passes &= passesRule(key, groupRule);
            }
            if (passes) {
                next.put(key, all.get(key));
            }
        }

        for (StageKey nextKey : next.keySet()) {
            all.remove(nextKey);
        }
        if (next.size() > 0) {
            grp.inc();
        }
        return next;
    }

    private boolean passesRule(StageKey key, GroupRule rule) {
        String valueToCheck = rule.getValueType().equals("chart") ? key.getChart() : key.getNamespace();
        boolean valueInList = rule.getList().contains(valueToCheck);
        return rule.getRuleType().equals("include") == valueInList;
    }
}
