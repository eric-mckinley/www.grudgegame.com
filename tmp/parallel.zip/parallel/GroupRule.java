package com.mckinleyit.parallel;

import lombok.Data;

import java.util.List;

@Data
public class GroupRule {
    private String valueType;
    private String ruleType;
    private List<String> list;
}
