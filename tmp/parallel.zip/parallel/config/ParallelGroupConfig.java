package com.mckinleyit.parallel.config;

import com.mckinleyit.parallel.GroupRule;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class ParallelGroupConfig {

    private String name;
    private int maxSize;
    private boolean pauseWhenFailure;
    private int executionLimit = 0;
    private List<GroupRule> rules;
}
