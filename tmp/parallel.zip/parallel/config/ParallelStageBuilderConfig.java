package com.mckinleyit.parallel.config;

import lombok.Data;

@Data
public class ParallelStageBuilderConfig {

    private int maxSize;
    private ParallelGroupConfig[] parallelGroupConfigs;

    public ParallelStageBuilderConfig() {
        this.parallelGroupConfigs = new ParallelGroupConfig[0];
    }
}
