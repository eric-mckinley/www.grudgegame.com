package com.mckinleyit.parallel;

import com.mckinleyit.parallel.config.ParallelGroupConfig;
import lombok.Getter;

@Getter
public class ParallelStages {

    private int usageCount;
    private ParallelGroupConfig config;

    public ParallelStages(ParallelGroupConfig config) {
        this.config = config;
    }

    public void inc(){
        usageCount++;
    }

}
