package com.mckinleyit.parallel;

import java.util.Objects;
import java.util.StringJoiner;

public class StageKey {

    private String chart;
    private String namespace;

    public StageKey(String chart, String namespace) {
        this.chart = chart;
        this.namespace = namespace;
    }

    public String getChart() {
        return chart;
    }

    public String getNamespace() {
        return namespace;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StageKey stageKey = (StageKey) o;
        return Objects.equals(chart, stageKey.chart) &&
                Objects.equals(namespace, stageKey.namespace);
    }

    @Override
    public int hashCode() {
        return Objects.hash(chart, namespace);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", StageKey.class.getSimpleName() + "[", "]")
                .add("chart='" + chart + "'")
                .add("namespace='" + namespace + "'")
                .toString();
    }
}
